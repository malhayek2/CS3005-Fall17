// ConsoleApplication4.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "PPM.h"

int main()
{
	PPM result;
	PPM myPPM;
	for (int c = 0; c < 10000; c++) {
		myPPM.red[c] = c;
	}
	for (int c = 0; c < 10000; c++) {
		myPPM.green[c] = c;
	}
	for (int c = 0; c < 10000; c++) {
		myPPM.blue[c] = c;
	}
	PPM myPPM2;
	for (int c = 10000; c > 0; c--) {
		myPPM2.red[c] = c;
	}
	for (int c = 10000; c > 0; c--) {
		myPPM2.green[c] = c;
	}
	for (int c = 10000; c > 0; c--) {
		myPPM2.blue[c] = c;
	}
	myPPM.set_height(100);
	myPPM.set_weight(100);
	myPPM.set_maxval(255);
	cout << "Let our steam1 PPM1 be P6 100 100 255 1 1 1 2 2 2 3 3 3 4 4 4 5 5 5 ... 100" << endl;
	cout << "Let our steam2-PPM2 be P6 100 100 255 100 100 100 99 99 99 98 98 98 ... 100" << endl;
	cout << "print out of PPM" << endl;
	cout << "Please choice one of the following operations 0-print out PPM1 PPM2 1-PPM1+PPM2 2-PPM2-PPM1 3-PPM1+=PPM2 \n 4-PPM1-=PPM2 5-PPM1 * double 6-PPM1/double. 7- comapre PPM > PPM2 8 - PPM < PPM2 " << endl;
	int m;

	double mutilpler;
	while (cin >> m) {
		if (m == 0) cout << myPPM << endl << myPPM2;
		if (m == 1 || m == 3) cout << myPPM + myPPM2;
		if (m == 2 || m == 4)  cout << myPPM2 - myPPM;

		if (m == 5) {
			cout << "enter doubles: ";
			cin >> mutilpler;
			cout << myPPM * mutilpler;
		}
		if (m == 6) {
			cout << "enter doubles: ";
			cin >> mutilpler;
			cout << myPPM / mutilpler;
		}
		if (m == 7) cout << (myPPM < myPPM2);
		if (m == 8) cout << (myPPM > myPPM2);
	}
	
	system("pause");
    return 0;
}

