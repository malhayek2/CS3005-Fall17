#ifndef _PPM_H_
#define _PPM_H_
#include "PPM.h"

#include <iostream>
#include <string>
using namespace std;
#define MAX_ITEMS 10000
#define MAX_COLOR 255
class PPM {
public:

	int red[MAX_ITEMS];
	int green[MAX_ITEMS];
	int blue[MAX_ITEMS];
	 PPM();
	//	PPM load(string filename);
	PPM& operator+=(const PPM& b);
	PPM& operator-=(const PPM& b);
	void set_maxval(int h);
	void set_weight(int m);
	void set_height(int s);
	void fix();
	void get_red();
	void get_blue();
	void get_green();
	int get_height() const;
	int get_width() const;
	int get_maxval() const;
	bool operator<(const PPM& rhs) const; //less than
	bool operator>(const PPM& rhs) const;
	PPM operator+(const PPM& rhs) const;
	PPM operator-(const PPM& rhs) const;
	PPM operator*(const double& rhs) const;
	PPM operator*=(const double& rhs);
	PPM operator/(const double& rhs) const;
	PPM operator/=(const double& rhs);


private:

	int maxval;
	int weight;
	int height;
	string header;

};



std::ostream& operator<<(std::ostream& os, PPM& c);
PPM operator>>(std::istream& os, const  PPM& c);
#endif