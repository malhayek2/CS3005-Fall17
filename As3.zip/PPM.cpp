// functions

#include <iostream>
#include "stdafx.h"
#include "PPM.h"


PPM::PPM() {
	maxval = 255;
	header = "P6\n";
	height = 1;
	weight = 1;
}

void PPM::set_maxval(int h)
{
	maxval = h;
}

void PPM::set_weight(int m)
{
	weight = m;
}

void PPM::set_height(int s)
{
	height = s;
}
int PPM::get_height() const {
	return height;
}

int PPM::get_width() const {
	return weight;
}
int PPM::get_maxval() const {
	return maxval;
}
void PPM::get_red() {
	
	for (unsigned int k = 0; k < MAX_ITEMS; k++) // or size of heught
	{
		 cout << red[k];
	}


}
void PPM::get_blue() {
	string s;
	for (unsigned int a = 0; a < MAX_ITEMS; a++) // or size of heught
	{
		cout << (blue[a]);

	}

}
void PPM::fix() {
	for (int c = 0; c < 10000; c++) {
		if (red[c] < 0) red[c] = 0;
		if (red[c] > 255) red[c] = 255;
		if (blue[c] < 0) blue[c] = 0;
		if (blue[c] > 255) blue[c] = 255;
		if (green[c] < 0) green[c] = 0;
		if (green[c] > 255) green[c] = 255;
	}
}
void PPM::get_green() {

	for (unsigned int a = 0; a < MAX_ITEMS; a++) // or size of heught
	{
		cout << (green[a]);

	}
	
}
std::ostream& operator<<(std::ostream& fout, PPM& c) {
	c.fix();
	fout << "P6\n";
	fout << c.get_width() << "\n";
	fout << c.get_height() << "\n";
	fout << "255" << "\n";
	c.get_red();
	c.get_blue();
	c.get_green();
	return fout;
}

PPM operator>>(std::istream& inos, const PPM& c) {
	string type;
	int WIDTH;
	int HEIGHT;
	int maxval;
	string newline;
	PPM image;

	inos >> std::skipws >> type >> WIDTH >> HEIGHT >> maxval >> newline;
	image.set_height(HEIGHT);
	image.set_maxval(maxval);
	image.set_weight(WIDTH);
	int pointer = 0;
	for (int y = 0; y < image.get_height(); y++) {

		for (int x = 1; x < image.get_width() + 1; x++) {
			if (y != 0) {
				pointer = ((y*image.get_width())) + x;
			} if (y == 0) {
				pointer = (x + y);
			}

			for (int c = 0; c < 3; c++) {
				if (c == 0) { inos >> std::skipws >> image.red[pointer]; }
				if (c == 1) { inos >> std::skipws >> image.green[pointer]; }
				if (c == 2) { inos >> std::skipws >> image.blue[pointer]; }
			}
		}
	}
	return image;
}
// ppm1 < ppm2 ?
bool PPM::operator<(const PPM& rhs) const {
	int pix1 = height*weight;
	int pix2 = (rhs.get_width()*rhs.get_height());
	if (pix1 < pix2) return true; // 1
	if (pix1 > pix2) return false; // -1
	return false; // 0
}
bool PPM::operator>(const PPM& rhs) const {
	int pix1 = height*weight;
	int pix2 = (rhs.get_width()*rhs.get_height());
	if (pix1 > pix2) return true; // 1
	if (pix1 < pix2) return false; // -1
	return false; // 0
}

PPM PPM::operator+(const PPM& rhs) const {
	
	int newwidth = get_width();
	if (get_width() > rhs.get_width()) newwidth = get_width();
	if (get_width() < rhs.get_width()) newwidth = rhs.get_width();
	int newheight = get_height();
	if (get_height() > rhs.get_height()) newheight = get_height();
	if (get_height() < rhs.get_height()) newheight = rhs.get_height();
	PPM newPPM;
	int pointer = 0;
	for (int y = 0; y < newheight; y++) {
		for (int x = 1; x < newwidth + 1; x++) {
			if (y != 0) {
				pointer = ((y*newwidth)) + x;
			} if (y == 0) {
				pointer = (x + y);
			}

			newPPM.red[pointer] = red[pointer] + rhs.red[pointer];
			newPPM.green[pointer] = green[pointer] + rhs.green[pointer];
			newPPM.blue[pointer] = blue[pointer] + rhs.blue[pointer];
			if (red[pointer] + rhs.red[pointer] > 255) newPPM.red[pointer] = 255;
			if (green[pointer] + rhs.green[pointer] > 255) newPPM.green[pointer] = 255;
			if (blue[pointer] + rhs.blue[pointer] > 255) newPPM.blue[pointer] = 255;

		}
	}
	return newPPM;
}
PPM& PPM::operator+=(const PPM& rhs) {
	int newwidth = get_width();
	if (get_width() > rhs.get_width()) newwidth = get_width();
	if (get_width() < rhs.get_width()) newwidth = rhs.get_width();
	int newheight = get_height();
	if (get_height() > rhs.get_height()) newheight = get_height();
	if (get_height() < rhs.get_height()) newheight = rhs.get_height();
	PPM newPPM;
	int pointer = 0;
	for (int y = 0; y < newheight; y++) {
		for (int x = 1; x < newwidth + 1; x++) {
			if (y != 0) {
				pointer = ((y*newwidth)) + x;
			} if (y == 0) {
				pointer = (x + y);
			}

			newPPM.red[pointer] = red[pointer] + rhs.red[pointer];
			newPPM.green[pointer] = green[pointer] + rhs.green[pointer];
			newPPM.blue[pointer] = blue[pointer] + rhs.blue[pointer];
			if (red[pointer] + rhs.red[pointer] > 255) newPPM.red[pointer] = 255;
			if (green[pointer] + rhs.green[pointer] > 255) newPPM.green[pointer] = 255;
			if (blue[pointer] + rhs.blue[pointer] > 255) newPPM.blue[pointer] = 255;

		}
	}
	return newPPM;
}

PPM PPM::operator-(const PPM& rhs) const {
	int newwidth = get_width();
	if (get_width() > rhs.get_width()) newwidth = get_width();
	if (get_width() < rhs.get_width()) newwidth = rhs.get_width();
	int newheight = get_height();
	if (get_height() > rhs.get_height()) newheight = get_height();
	if (get_height() < rhs.get_height()) newheight = rhs.get_height();
	PPM newPPM;
	int pointer = 0;
	for (int y = 0; y < newheight; y++) {
		for (int x = 1; x < newwidth + 1; x++) {
			if (y != 0) {
				pointer = ((y*newwidth)) + x;
			} if (y == 0) {
				pointer = (x + y);
			}
			newPPM.red[pointer] = red[pointer] - rhs.red[pointer];
			newPPM.green[pointer] = green[pointer] - rhs.green[pointer];
			newPPM.blue[pointer] = blue[pointer] - rhs.blue[pointer];
			if (red[pointer] + rhs.red[pointer] < 0) newPPM.red[pointer] = 0;
			if (green[pointer] + rhs.green[pointer] < 0) newPPM.green[pointer] = 0;
			if (blue[pointer] + rhs.blue[pointer] < 0) newPPM.blue[pointer] = 0;

		}
	}
	return newPPM;
}
PPM& PPM::operator-=(const PPM& rhs) {
	int newwidth = get_width();
	if (get_width() > rhs.get_width()) newwidth = get_width();
	if (get_width() < rhs.get_width()) newwidth = rhs.get_width();
	int newheight = get_height();
	if (get_height() > rhs.get_height()) newheight = get_height();
	if (get_height() < rhs.get_height()) newheight = rhs.get_height();
	PPM newPPM;
	int pointer = 0;
	for (int y = 0; y < newheight; y++) {
		for (int x = 1; x < newwidth + 1; x++) {
			if (y != 0) {
				pointer = ((y*newwidth)) + x;
			} if (y == 0) {
				pointer = (x + y);
			}
			newPPM.red[pointer] = red[pointer] - rhs.red[pointer];
			newPPM.green[pointer] = green[pointer] - rhs.green[pointer];
			newPPM.blue[pointer] = blue[pointer] - rhs.blue[pointer];
			if (red[pointer] + rhs.red[pointer] < 0) newPPM.red[pointer] = 0;
			if (green[pointer] + rhs.green[pointer] < 0) newPPM.green[pointer] = 0;
			if (blue[pointer] + rhs.blue[pointer] < 0) newPPM.blue[pointer] = 0;

		}
	}
	return newPPM;
}
PPM PPM::operator*(const double& rhs) const {
	int newwidth = get_width();

	int newheight = get_height();

	PPM newPPM;
	int pointer = 0;
	for (int y = 0; y < newheight; y++) {
		for (int x = 1; x < newwidth + 1; x++) {
			if (y != 0) {
				pointer = ((y*newwidth)) + x;
			} if (y == 0) {
				pointer = (x + y);
			}
			newPPM.red[pointer] = red[pointer] * rhs;
			newPPM.green[pointer] = green[pointer] * rhs;
			newPPM.blue[pointer] = blue[pointer] * rhs;
			if (red[pointer] * rhs > 255) newPPM.red[pointer] = 255;
			if (green[pointer] * rhs > 255) newPPM.green[pointer] = 255;
			if (blue[pointer] * rhs > 255) newPPM.blue[pointer] = 255;

		}
	}
	return newPPM;


}
PPM PPM::operator*=(const double& rhs) {
	int newwidth = get_width();

	int newheight = get_height();

	PPM newPPM;
	int pointer = 0;
	for (int y = 0; y < newheight; y++) {
		for (int x = 1; x < newwidth + 1; x++) {
			if (y != 0) {
				pointer = ((y*newwidth)) + x;
			} if (y == 0) {
				pointer = (x + y);
			}
			newPPM.red[pointer] = red[pointer] * rhs;
			newPPM.green[pointer] = green[pointer] * rhs;
			newPPM.blue[pointer] = blue[pointer] * rhs;
			if (red[pointer] * rhs > 255) newPPM.red[pointer] = 255;
			if (green[pointer] * rhs > 255) newPPM.green[pointer] = 255;
			if (blue[pointer] * rhs > 255) newPPM.blue[pointer] = 255;

		}
	}
	return newPPM;
}
PPM PPM::operator/(const double& rhs) const {
	int newwidth = get_width();

	int newheight = get_height();

	PPM newPPM;
	int pointer = 0;
	for (int y = 0; y < newheight; y++) {
		for (int x = 1; x < newwidth + 1; x++) {
			if (y != 0) {
				pointer = ((y*newwidth)) + x;
			} if (y == 0) {
				pointer = (x + y);
			}
			newPPM.red[pointer] = red[pointer] / rhs;
			newPPM.green[pointer] = green[pointer] / rhs;
			newPPM.blue[pointer] = blue[pointer] / rhs;


		}
	}
	return newPPM;


}
PPM PPM::operator/=(const double& rhs) {
	int newwidth = get_width();

	int newheight = get_height();

	PPM newPPM;
	int pointer = 0;
	for (int y = 0; y < newheight; y++) {
		for (int x = 1; x < newwidth + 1; x++) {
			if (y != 0) {
				pointer = ((y*newwidth)) + x;
			} if (y == 0) {
				pointer = (x + y);
			}
			newPPM.red[pointer] = red[pointer] / rhs;
			newPPM.green[pointer] = green[pointer] / rhs;
			newPPM.blue[pointer] = blue[pointer] / rhs;
		}
	}
	return newPPM;
}