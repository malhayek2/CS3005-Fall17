// ConsoleApplication3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "rps.h"
int userWins = 0;
int userTies = 0;
int CPUwins = 0;
int main()
{
	rps myRPS;
	do {
		myRPS.initializeRandomNumbers();
		int playerchoice;
		int CPUchoice;
		CPUchoice = myRPS.getRandomPlayerChoice();
		playerchoice = myRPS.getUserPlayerChoice(cin, cout);
		int calcWinner;
		calcWinner = myRPS.determineWinner(playerchoice, CPUchoice);
//		cout << calcWinner;
		myRPS.displayMatchResults(cout, playerchoice, CPUchoice, calcWinner);
		if (calcWinner == 11) userWins++;
		if (calcWinner == 12) CPUwins++;
		if (calcWinner == 13) userTies++;
		myRPS.displayStatistics(cout, userWins, CPUwins, userTies);
	} while (myRPS.askUserIfGameShouldContinue(cin, cout));




	return 0;
}

