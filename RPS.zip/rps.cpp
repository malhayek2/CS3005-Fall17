// functions

#include <cstdlib>
#include <iostream>

#include "rps.h"
#include <ctime>
#include <conio.h>


void rps::initializeRandomNumbers() {
 // does nothing 
}
int rps::getRandomPlayerChoice() {

	int random_number = (rand() % 3) + 1;

	return random_number;
}
int rps::determineWinner(int user_choice, int random_choice) {
	if ((user_choice == 1 && random_choice == 3) || (user_choice == 2 && random_choice == 1) || (user_choice == 3 && random_choice == 2)) {
		return 11;
		//	userCount++;
	}
	if (user_choice == random_choice) {

		return 13;
	}
	else if ((user_choice == 3 && random_choice == 1) || (user_choice == 1 && random_choice == 2) || (user_choice == 2 && random_choice == 3)) {
		return 12;
		//	pcCount++;
	}
	return 12;
}
int rps::getUserPlayerChoice(std::istream& input_stream, std::ostream& output_stream) {
	output_stream << "\nWelcome To Rock, Paper, Scissors\n";
	output_stream << "Lets play, please choose one of the following\n";
	output_stream << "1 = Rock\n";
	output_stream << "2 =  Paper\n";
	output_stream << "3 = Scissors\n";
	//output_stream << "End of line or Shift + D or invaild entry will terminate the game";

	int whatever;

	while (input_stream >> whatever) {
		if (whatever == 1 || whatever == 2 || whatever == 3) break;
	}
	return whatever;
}
void rps::displayMatchResults(std::ostream& output_stream, int user_choice, int random_choice, int winner) {
	output_stream <<  "Player have played :";
	if (user_choice == 1)output_stream << "Rock \n" ;
	if (user_choice == 2)output_stream << "Paper \n" ;
	if (user_choice == 3)output_stream << "Scissors \n";
	output_stream <<  "Random have played :";
	if (random_choice == 1)output_stream << "Rock \n" ;
	if (random_choice == 2)output_stream << "Paper \n" ;
	if (random_choice == 3) output_stream << "Scissors \n";
//	if (determineWinner(user_choice, random_choice) == 11) " Winner is Player";
//	if (determineWinner(user_choice, random_choice) == 12) " Winner is Random";
//	if (determineWinner(user_choice, random_choice) == 13) " TIE";
	if (winner == 11) output_stream << "Winner is Player \n";
	if (winner == 12) output_stream << "Winner is Random \n";
	if (winner == 13) output_stream << "TIE \n";
}
void rps::displayStatistics(std::ostream& output_stream, int number_user_wins, int number_user_losses, int number_user_ties) {
	output_stream << "Player has won : "; output_stream << number_user_wins;
	output_stream << "\nPlayer has tied : "; output_stream << number_user_ties;
	output_stream << "\nPlayer has lost : "; output_stream << number_user_losses;
}

bool rps::askUserIfGameShouldContinue(std::istream& input_stream, std::ostream& output_stream) {
	char ans = 'K';
		
			output_stream << "\n Do you want to continue (Y/N)?\n";
			output_stream << "You must type 'N' to quit :";
			//input_stream >> ans;
			ans = _getche();
			ans = toupper(ans);
		if (((ans != 'N'))) {
				return true;
		} 
		return false;
		
}

